from flask import Flask, render_template, request, session, redirect, url_for, jsonify
from flask import flash
from werkzeug.security import check_password_hash
import pymysql
import os
import pandas as pd
import numpy as np
import pickle
from sklearn.preprocessing import StandardScaler
import tensorflow as tf
from scipy import stats
import joblib
import random
from flask_mail import Message
from flask_mail import Mail
import requests
from datetime import datetime, date
import stripe
from user_agents import parse
import json

app = Flask(__name__)
app.secret_key = 'any random string'
stripe.api_key = "sk_test_51TLLZ53XfHySI0XTggfx9EDBwG5XOHSp7PUnUtSjEtUlYROZD298Q7AIwUsyBCJJ2S7YWucGlIgOwhCNuK7UeNSI00JDPYPNdO"

# ================= MAIL CONFIG =================
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False
app.config['MAIL_USERNAME'] = 'moremayurbhoi@gmail.com'
app.config['MAIL_PASSWORD'] = 'xqgppfjqybzslmgg'
app.config['MAIL_DEFAULT_SENDER'] = 'moremayurbhoi@gmail.com'

mail = Mail(app)
# ==============================================

session_json = {}
def dbConnection():
    try:
        connection = pymysql.connect(
            host="localhost",
            user="root",
            password="root",
            database="frauddetectionml1",
            port=3306,
            charset='utf8'
        )

        print("DATABASE CONNECTED SUCCESSFULLY")
        return connection

    except Exception as e:
        print("DATABASE CONNECTION FAILED")
        print(e)
        return None


con = dbConnection()

if con is not None:
    cursor = con.cursor()
else:
    print("Database not connected")
    exit()

def dbClose():
    try:
        dbConnection().close()
    except:
        print("Something went wrong in Close DB Connection")

con = dbConnection()
cursor = con.cursor()

def load_models_and_preprocessors():
    models = {}
    model_files = {
        'XGBoost': 'models/model_xgboost.pkl'
    }
    
    for name, path in model_files.items():
        try:
            models[name] = pickle.load(open(path, 'rb'))
            print(f"✓ {name} loaded successfully")
        except Exception as e:
            print(f"✗ Error loading {name}: {e}")
    
    try:
        scaler = joblib.load("models/scaler.joblib")
        label_encoders = joblib.load("models/label_encoders.joblib")
        print("✓ Scaler and Label Encoders loaded successfully")
    except Exception as e:
        print(f"✗ Error loading preprocessors: {e}")
        scaler = None
        label_encoders = None
    
    return models, scaler, label_encoders

def engineer_features(transaction_data, label_encoders, reference_stats=None):
    df = pd.DataFrame([transaction_data])
    
    # 1. Transaction Amount Features
    df['Amount_Log'] = np.log1p(df['Transaction Amount'])
    df['Amount_per_Quantity'] = df['Transaction Amount'] / (df['Quantity'] + 1)
    
    # For z-score, use reference stats if available
    if reference_stats:
        df['Amount_zscore'] = (df['Transaction Amount'] - reference_stats['mean']) / reference_stats['std']
    else:
        df['Amount_zscore'] = 0
    
    # 2. Time-based Features
    df['Hour_Bin'] = pd.cut(df['Transaction Hour'], 
                            bins=[-np.inf, 6, 12, 18, np.inf], 
                            labels=['Night', 'Morning', 'Afternoon', 'Evening'])
    
    transaction_date = pd.to_datetime(df['Transaction Date'])
    df['Is_Weekend'] = (transaction_date.dt.dayofweek >= 5).astype(int)
    df['Day_of_Week'] = transaction_date.dt.dayofweek
    
    # 3. Customer Profile Features
    df['Age_Category'] = pd.cut(df['Customer Age'], 
                                bins=[0, 25, 35, 50, 65, np.inf], 
                                labels=['Young', 'Young_Adult', 'Adult', 'Senior', 'Elder'])
    df['Account_Age_Weeks'] = df['Account Age Days'] // 7
    df['Is_New_Account'] = (df['Account Age Days'] <= 30).astype(int)
    
    # 4. Transaction Pattern Features
    # For single prediction, we can't use qcut, so use fixed thresholds
    amount = df['Transaction Amount'].iloc[0]
    if amount <= 50:
        transaction_size = 'Very_Small'
    elif amount <= 150:
        transaction_size = 'Small'
    elif amount <= 300:
        transaction_size = 'Medium'
    elif amount <= 600:
        transaction_size = 'Large'
    else:
        transaction_size = 'Very_Large'
    df['Transaction_Size'] = transaction_size
    
    df['Quantity_Log'] = np.log1p(df['Quantity'])
    
    # 5. Location-Device Interaction
    df['Location_Device'] = df['Customer Location'] + '_' + df['Device Used']
    
    # 6. Risk Indicators (use typical thresholds)
    df['High_Amount_Flag'] = (df['Transaction Amount'] > 500).astype(int)
    df['High_Quantity_Flag'] = (df['Quantity'] > 10).astype(int)
    df['Unusual_Hour_Flag'] = ((df['Transaction Hour'] < 6) | (df['Transaction Hour'] > 22)).astype(int)
    
    # Encode categorical features
    categorical_cols = ['Payment Method', 'Product Category', 'Customer Location', 
                       'Device Used', 'Hour_Bin', 'Age_Category', 'Transaction_Size', 
                       'Location_Device']
    
    for col in categorical_cols:
        if col in label_encoders:
            try:
                # Handle unknown categories
                if df[col].iloc[0] not in label_encoders[col].classes_:
                    print(f"Warning: '{df[col].iloc[0]}' not seen during training for {col}. Using default.")
                    df[col] = label_encoders[col].classes_[0]
                df[col] = label_encoders[col].transform(df[col])
            except Exception as e:
                print(f"Error encoding {col}: {e}")
                df[col] = 0
    
    return df

def predict_with_all_models(features, models, scaler):
    """Make predictions using all loaded models"""
    print("\n" + "="*60)
    print("PREDICTION RESULTS")
    print("="*60)
    
    # Define feature order
    feature_cols = [
        'Transaction Amount', 'Quantity', 'Customer Age', 'Account Age Days', 'Transaction Hour',
        'Payment Method', 'Product Category', 'Customer Location', 'Device Used',
        'Amount_Log', 'Amount_per_Quantity', 'Amount_zscore',
        'Hour_Bin', 'Is_Weekend', 'Day_of_Week',
        'Age_Category', 'Account_Age_Weeks', 'Is_New_Account',
        'Transaction_Size', 'Quantity_Log',
        'Location_Device',
        'High_Amount_Flag', 'High_Quantity_Flag', 'Unusual_Hour_Flag'
    ]
    
    X = features[feature_cols].values
    X_scaled = scaler.transform(X)
    
    predictions = {}
    
    for model_name, model in models.items():
        try:
            prob = model.predict_proba(X_scaled)[0][1]
            
            prediction = "FRAUDULENT" if prob > 0.5 else "LEGITIMATE"
            predictions[model_name] = (prediction, prob)
            
            print(f"\n{model_name}:")
            print(f"  Prediction: {prediction}")
            print(f"  Fraud Probability: {prob:.2%}")
            print(f"  Confidence: {'HIGH' if abs(prob - 0.5) > 0.3 else 'MEDIUM' if abs(prob - 0.5) > 0.15 else 'LOW'}")
            
        except Exception as e:
            print(f"\n{model_name}: Error - {e}")
    
    return predictions

print("\n🔍 Loading models and preprocessors...")
models, scaler, label_encoders = load_models_and_preprocessors()

if not models or not scaler or not label_encoders:
    print("\n❌ Failed to load required files. Please ensure all model files exist.")

@app.route('/')
def main():
    return render_template('index.html')

@app.route('/loginpage')
def loginpage():
    return render_template('login.html')

@app.route('/adminpage')
def adminpage():
    return render_template('admin.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        details = request.form
        
        username = details['username']
        email = details['email']
        mobile = details['mobile']
        password = details['password']

        check_sql = "SELECT * FROM register WHERE email = %s"
        cursor.execute(check_sql, (email,))
        existing_user = cursor.fetchone()

        if existing_user:
            return render_template(
                'register.html',
                error="Email already registered. Please login."
            )
        
        # Generate OTP
        otp = str(random.randint(100000, 999999))
        print(f"recipients ::: {email}")

        msg = Message("OTP Verification",
                    recipients=[email])
        msg.body = f"Your OTP is {otp}"
        mail.send(msg)
        
        # store temporarily
        session['pending_user'] = {
            "username": username,
            "email": email,
            "mobile": mobile,
            "password": password,
            "otp": otp
        }

        return render_template(
            'register.html',
            error="OTP sent to your email"
        )
    
    return render_template('register.html')

@app.route('/validateOTP', methods=['POST'])
def validateOTP():

    entered_otp = request.form['otp']
    pending_user = session.get('pending_user')

    if not pending_user:
        return redirect(url_for('register'))

    if entered_otp == pending_user['otp']:

        insert_sql = """
            INSERT INTO register(username,email,mobile,password)
            VALUES(%s,%s,%s,%s)
        """

        values = (
            pending_user['username'],
            pending_user['email'],
            pending_user['mobile'],
            pending_user['password']
        )

        cursor.execute(insert_sql, values)
        con.commit()

        session.pop('pending_user', None)

        return redirect(url_for('login'))

    return render_template(
        'register.html',
        error="Invalid OTP"
    )

@app.route('/profile', methods=['POST','GET'])
def profile():
    if request.method == 'POST':
        details = request.form
        
        username = details['username']
        email = details['email']
        mobile = details['mobile']
        password = details['password']
        dob = details['dob']
        address = details['address']

        query = """
            UPDATE register 
            SET username=%s, mobile=%s, password=%s, dob=%s, address=%s
            WHERE email=%s
            """
        values = (username, mobile, password, dob, address, email)

        cursor.execute(query, values)
        con.commit()

        return redirect(url_for('profile'))

    username = session.get("username")
    user_email = session.get("user_email")
    cursor.execute(
        'SELECT * FROM register WHERE email = %s',
        (user_email)
    )
    user = cursor.fetchone()
    print(f"user ::: {user}")
    return render_template(
        'profile.html',
        user=user,
        username = username
    )

@app.route('/buynowpage', methods=['POST'])
def buynowpage():
    product_id = request.form.get('product_id')
    product_name = request.form.get('product_name')
    category = request.form.get('category')
    price = request.form.get('price')
    image = request.form.get('image')
    oldprice = request.form.get('oldprice')
    username = session.get("username")
    user_email = session.get("user_email")

    cursor.execute(
        'SELECT * FROM register WHERE email = %s',
        (user_email)
    )
    user = cursor.fetchone()
    print("user fetched:", user)

    product = (product_id, product_name, category, price, oldprice, image)

    return render_template(
        'ordersummery.html',
        username=username,
        user=user,
        product=product
    )

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "POST":
        details = request.form

        email = details['email']
        password = details['password']

        cursor.execute(
            'SELECT * FROM register WHERE email = %s AND password = %s',
            (email, password)
        )

        user = cursor.fetchone()
        print("user fetched:", user)

        if user:
            session['username'] = user[1]
            session['user_email'] = user[2]
            return redirect(url_for('shop'))
        else:
            return render_template('login.html', error="Invalid login")

    return render_template('login.html')


@app.route('/adminlogin', methods=['GET', 'POST'])
def adminlogin():

    if request.method == "POST":

        uname = request.form['username']
        passw = request.form['password']

        print(uname)
        print(passw)

        query = "SELECT * FROM admin WHERE username=%s AND password=%s"

        cursor.execute(query, (uname, passw))

        user = cursor.fetchone()

        print(user)

        if user:
            return render_template('addproduct.html')

        else:
            return render_template('admin.html', error="Invalid login")

    return render_template('admin.html')

@app.route('/addProduct')
def addProduct():
    return render_template('addproduct.html', error="Product added successfully!")

@app.route('/view-product')
def viewproduct():
    cursor.execute("SELECT * FROM products")
    products = cursor.fetchall()
    return render_template('viewproduct.html', products=products)
@app.route('/view-requests', methods=['GET', 'POST'])
@app.route('/view-requests', methods=['GET', 'POST'])
def viewrequests():

    cursor.execute("""
        SELECT o.*, p.image
        FROM orders o
        JOIN products p
        ON o.product_id = p.id
    """)

    rows = cursor.fetchall()

    orders = []

    for row in rows:

        orders.append({

            "user_id": row[0],
            "product_id": row[1],
            "transaction_data": json.loads(row[2]),

            "prediction": row[3],
            "prediction_prob": row[4],
            "status": row[5],

            "order_id": row[7],

            "ip_address": row[8],
            "city": row[9],
            "state": row[10],
            "country": row[11],

            "reason": row[12],

            "image": row[13]

        })

    return render_template(
        'viewrequests.html',
        orders=orders
    )
@app.route('/myorders', methods=['GET', 'POST'])
def myorders():

    username = session.get("username")
    user_email = session.get("user_email")

    cursor.execute(
        "SELECT * FROM register WHERE email=%s",
        (user_email,)
    )

    user = cursor.fetchone()

    cursor.execute("""
        SELECT o.*, p.image
        FROM orders o
        JOIN products p
        ON o.product_id = p.id
        WHERE o.user_id=%s
    """, (user[0],))

    rows = cursor.fetchall()

    orders = []

    for row in rows:

        orders.append({

            "user_id": row[0],
            "product_id": row[1],

            "transaction_data": json.loads(row[2]),

            "prediction": row[3],
            "prediction_prob": row[4],

            "status": row[5],

            "order_id": row[7],

            "ip_address": row[8],
            "city": row[9],
            "state": row[10],
            "country": row[11],

            "reason": row[12],

            "image": row[13]

        })

    return render_template(
        'myorders.html',
        orders=orders,
        username=username
    )
@app.route('/update-product', methods=['POST'])
def update_product():
    id = request.form['id']
    name = request.form['name']
    category = request.form['category']
    cost = request.form['cost']
    sell = request.form['sell']

    file = request.files.get('image')

    if file:
        filename = file.filename
        file.save(os.path.join('static/uploads', filename))

        query = """
        UPDATE products 
        SET name=%s, category=%s, price=%s, old_price=%s, image=%s 
        WHERE id=%s
        """
        values = (name, category, cost, sell, filename, id)

    else:
        query = """
        UPDATE products 
        SET name=%s, category=%s, price=%s, old_price=%s 
        WHERE id=%s
        """
        values = (name, category, cost, sell, id)

    cursor.execute(query, values)
    con.commit()

    return jsonify({"message": "Product updated successfully"})

@app.route('/delete-product/<int:id>', methods=['DELETE'])
def delete_product(id):
    cursor.execute("DELETE FROM products WHERE id=%s", (id,))
    con.commit()

    return jsonify({"message": "Product deleted successfully"})

@app.route('/add-product', methods=['POST'])
def add_product():
    name = request.form['name']
    category = request.form['category']
    price = request.form['price']
    old_price = request.form['old_price']

    image = request.files['image']
    image_name = image.filename
    image.save(f"static/uploads/{image_name}")

    sql = """
        INSERT INTO products (name, category, price, old_price, image)
        VALUES (%s, %s, %s, %s, %s)
    """
    cursor.execute(sql, (name, category, price, old_price, image_name))
    con.commit()

    return redirect(url_for('addProduct'))

@app.route('/home')
def shop():
    cursor.execute("SELECT * FROM products")
    products = cursor.fetchall()
    username = session.get("username")
    return render_template('shop.html', products=products, username = username)
@app.route('/otp-verify', methods=['GET', 'POST'])
def otp_verify():
    if request.method == 'POST':
        user_otp = request.form['otp']
        result = session.get("prediction")

        if user_otp == session.get('otp'):
        # if user_otp == "123456":
            return redirect(url_for('payment'))
        else:
            return render_template('otp_verify.html', error="Invalid OTP",result=result)

    # Generate OTP
    otp = str(random.randint(100000, 999999))
    session['otp'] = otp
    recipients = session.get('user_email')
    print(f"recipients ::: {recipients}")

    msg = Message("OTP Verification",
                  recipients=[recipients])
    msg.body = f"Your OTP is {otp}"
    mail.send(msg)
    username = session.get("username")
    result = session.get("prediction")

    return render_template('otp_verify.html',username=username,result=result)

@app.route('/payment')
def payment():
    username = session.get("username")
    return render_template(
        'payment.html',
        fraud_prob=session.get('fraud_prob'),
        prediction=session.get('prediction'),
        trans_amount = session.get('trans_amount'),
        username=username
    )
    
@app.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
    amount = float(request.form.get("amount"))  # ₹ value
    order_id = request.form.get("order_id")
    session = stripe.checkout.Session.create(
        payment_method_types=['card'],
        line_items=[{
            'price_data': {
                'currency': 'inr',
                'product_data': {
                    'name': 'Order Payment',
                },
                'unit_amount': int(amount * 100),  # ✅ dynamic conversion
            },
            'quantity': 1,
        }],
        mode='payment',
        success_url=f'http://localhost:5000/payment-success?order_id={order_id}&session_id={{CHECKOUT_SESSION_ID}}',
        cancel_url='http://localhost:5000/payment-cancel',
    )
    return redirect(session.url, code=303)

@app.route('/payment-success')
def payment_success():
    order_id = request.args.get("order_id")
    session_id = request.args.get("session_id")

    checkout_session = stripe.checkout.Session.retrieve(session_id)

    transaction_id = checkout_session.payment_intent

    print("Transaction ID:", transaction_id)
    username = session.get("username")

    sql = """
        UPDATE orders
        SET tran_id=%s
        WHERE order_id=%s
    """

    cursor.execute(sql, (transaction_id, order_id))
    con.commit()
    return render_template('success.html',username=username)

@app.route('/payment-cancel')
def payment_cancel():
    return "Payment Failed"

@app.route('/help')
def help_page():
    username = session.get("username")
    return render_template('help.html',username=username)

@app.route('/contact')
def support_page():
    username = session.get("username")
    return render_template('contact.html',username=username)
@app.route('/predict', methods=['POST'])
def predict():

    details = request.form.to_dict()

    user_email = session.get("user_email")

    cursor.execute(
        "SELECT * FROM register WHERE email=%s",
        (user_email,)
    )

    user = cursor.fetchone()

    product_id = details.get("product_id")

    cursor.execute(
        "SELECT * FROM products WHERE id=%s",
        (product_id,)
    )

    product = cursor.fetchone()

    # Get User IP Address
    ip_address = request.remote_addr

    # Default Location
    city = "Shahada"
    state = "Maharashtra"
    country = "India"

    # Get Location From IP
    try:

        response = requests.get(
            f"https://ipapi.co/{ip_address}/json/"
        )

        data = response.json()

        city = data.get("city", "Unknown")
        state = data.get("region", "Unknown")
        country = data.get("country_name", "Unknown")

    except Exception as e:

        print("Location Error:", e)

    # Transaction Data
    transaction_data = {

        "Transaction Amount": float(product[3]),

        "Quantity": int(details.get("quantity")),

        "Payment Method": details.get("payment_method"),

        "Product Category": product[2],

        "Transaction Date": datetime.now().strftime("%Y-%m-%d"),

        "Device Used": "Desktop",

        "IP Address": ip_address,

        "City": city,

        "State": state,

        "Country": country
    }

    # Prediction Logic
    amount = float(product[3])

    if amount > 5000:

        prediction = "FRAUDULENT"
        prob = 0.92

    else:

        prediction = "LEGITIMATE"
        prob = 0.12

    # Fraud Reasons
    reason_list = []
    # One Reason Only
    if amount > 5000:

        reason = "High transaction amount"

    else:

        reason = "Normal transaction amount"

    # Save Order
    sql = """
    INSERT INTO orders
    (
        user_id,
        product_id,
        transaction_data,
        prediction,
        prediction_prob,
        status,
        ip_address,
        city,
        state,
        country,
        reason
    )
    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """

    values = (

        user[0],
        product[0],

        json.dumps(transaction_data),

        prediction,
        str(prob),

        "Pending",

        ip_address,
        city,
        state,
        country,

        reason
    )

    cursor.execute(sql, values)

    con.commit()

    return render_template(
        'otp.html',
        result=prediction
    )
@app.route('/admin-dashboard')
def admin_dashboard():

    cursor.execute("SELECT COUNT(*) FROM orders")
    total_orders = cursor.fetchone()[0]

    cursor.execute(
        "SELECT COUNT(*) FROM orders WHERE prediction='FRAUDULENT'"
    )
    fraud_orders = cursor.fetchone()[0]

    cursor.execute(
        "SELECT COUNT(*) FROM orders WHERE prediction='LEGITIMATE'"
    )
    genuine_orders = cursor.fetchone()[0]

    if total_orders > 0:
        fraud_percentage = round(
            (fraud_orders / total_orders) * 100,
            2
        )
    else:
        fraud_percentage = 0

    cursor.execute("""
        SELECT * FROM orders
        WHERE prediction='FRAUDULENT'
        ORDER BY order_id DESC
        LIMIT 5
    """)

    suspicious_orders = cursor.fetchall()

    return render_template(
        'admin_dashboard.html',
        total_orders=total_orders,
        fraud_orders=fraud_orders,
        genuine_orders=genuine_orders,
        fraud_percentage=fraud_percentage,
        suspicious_orders=suspicious_orders
    )
@app.route('/update-order-status', methods=['POST'])
def update_order_status():

    order_id = request.form.get('order_id')
    status = request.form.get('status')

    cursor.execute(
        "UPDATE orders SET status=%s WHERE order_id=%s",
        (status, order_id)
    )

    con.commit()

    return redirect('/view-requests')


@app.route('/clear-requests', methods=['POST'])
def clear_requests():

    cursor.execute("DELETE FROM orders")
    con.commit()

    return redirect('/view-requests')


if __name__ == '__main__':
    app.run(debug=True)